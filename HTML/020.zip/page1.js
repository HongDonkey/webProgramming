$(function(){
	
	$('.m1').click(function() {
		alert("hello");
	});

	$('.m2').click(function() {
		alert("click");
	});
	
});