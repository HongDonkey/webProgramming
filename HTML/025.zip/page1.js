$(function(){

	$('.m1').click(function() {
		$('.hide').animate({"height":"100px"}, 500);
		
	});

});