$(function(){

	$('p').click(function() {
//		$(this).append("hello");
		$(this).prepend("hello");
	});

});