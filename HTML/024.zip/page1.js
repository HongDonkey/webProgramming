$(function(){

	$('div').click(function() {
//		$('div').animate({"left":"300px"}, 500);
		$('div').animate({"left":"300px", "top":"50px"}, 500);
		
	});

});